# Agrega el codigo de la funcion nth_last_element() debajo
def nth_last_element(linked_list, n):
    head = linked_list.get_head_node()
    # Si la lista está vacía o el head no tiene valor, retorna None
    if head is None or head.get_value() is None:
        return None

    # Contar la longitud real (ignorando nodos con valor None)
    length = 0
    current = head
    while current is not None:
        if current.get_value() is not None:
            length += 1
        current = current.get_next_node()

    if n > length or n < 1:
        return None

    # Buscar el nodo en la posición (length - n) contando solo nodos con valor
    current = head
    index = 0
    target_index = length - n
    while current is not None:
        if current.get_value() is not None:
            if index == target_index:
                return current
            index += 1
        current = current.get_next_node()
    return None