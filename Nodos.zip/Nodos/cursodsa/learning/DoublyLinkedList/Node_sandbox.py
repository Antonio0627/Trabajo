# Escribe debajo el codigo de la clase Node y sus respectivos metodos        
from platform import node


class Node:
    def __init__(self, value,next_node=None,prev_node=None):
        self.value=value
        self.next_node=next_node 
        self.prev_node = prev_node
    def get_value(self):
        return self.value
    def get_next_node(self):
        return self.next_node
    def set_next_node(self, next_node):
        if not (isinstance(next_node, Node)  or isinstance(next_node, dict) or next_node is None):
            raise TypeError("next_node debe del tipo Node, dict, o None")
        self.next_node = next_node
    def set_prev_node(self, prev_node):
        if not (isinstance(prev_node, Node)  or isinstance(prev_node, dict) or prev_node is None):
            raise TypeError("prev_node debe del tipo Node, dict, o None")
        self.prev_node = prev_node
    def get_prev_node(self):
        return self.prev_node
    