# Escribe debajo el codigo de la clase DoublyLinkedList y sus respectivos metodos     
# Recuerda importar la clase Node en este script
from Node_sandbox import Node

class DoublyLinkedList:
    def __init__(self):
        self.head_node = None
        self.tail_node = None

    def add_to_head(self, value):
        new_node = Node(value)
        current_head = self.head_node
        if current_head is not None:
            current_head.set_prev_node(new_node)
            new_node.set_next_node(current_head)
        self.head_node = new_node
        if self.tail_node is None:
            self.tail_node = new_node
    def add_to_tail(self, value):
        new_node = Node(value)
        current_tail = self.tail_node
        if current_tail is not None:
            current_tail.set_next_node(new_node)
            new_node.set_prev_node(current_tail)
        self.tail_node = new_node
        if self.head_node is None:
            self.head_node = new_node
    def remove_head(self):
        if self.head_node is None:
            return None
        removed_head = self.head_node
        if self.head_node.get_next_node() is not None:
            self.head_node = self.head_node.get_next_node()
            self.head_node.set_prev_node(None)
        else:
            self.head_node = None
            self.tail_node = None
        return removed_head.get_value()
    def remove_tail(self):
        if self.tail_node is None:
            return None
        removed_tail = self.tail_node
        if self.tail_node.get_prev_node() is not None:
            self.tail_node = self.tail_node.get_prev_node()
            self.tail_node.set_next_node(None)
        else:
            self.head_node = None
            self.tail_node = None
        return removed_tail.get_value()
    def remove_by_value(self, value_to_remove):
        """
        Busca el primer nodo cuyo value == value_to_remove.
        Si no lo encuentra retorna None.
        Si lo encuentra, lo elimina de la lista y retorna el nodo eliminado.
        """
        node_to_remove = None
        current_node = self.head_node

        # Buscar el nodo a eliminar
        while current_node is not None:
            if current_node.get_value() == value_to_remove:
                node_to_remove = current_node
                break
            current_node = current_node.get_next_node()

        if node_to_remove is None:
            return None

        # Caso 1: es la cabeza
        if node_to_remove == self.head_node:
            self.head_node = node_to_remove.get_next_node()
            if self.head_node is not None:
                self.head_node.set_prev_node(None)
            else:
                # lista quedó vacía
                self.tail_node = None
            # despejar enlaces del nodo removido
            node_to_remove.set_next_node(None)
            node_to_remove.set_prev_node(None)
            return node_to_remove

        # Caso 2: es la cola
        if node_to_remove == self.tail_node:
            self.tail_node = node_to_remove.get_prev_node()
            if self.tail_node is not None:
                self.tail_node.set_next_node(None)
            else:
                # lista quedó vacía
                self.head_node = None
            node_to_remove.set_next_node(None)
            node_to_remove.set_prev_node(None)
            return node_to_remove

        # Caso 3: nodo en el medio
        next_node = node_to_remove.get_next_node()
        prev_node = node_to_remove.get_prev_node()

        if prev_node is not None:
            prev_node.set_next_node(next_node)
        if next_node is not None:
            next_node.set_prev_node(prev_node)

        node_to_remove.set_next_node(None)
        node_to_remove.set_prev_node(None)

        return node_to_remove

